const express = require('express')
const app = express()
app.use(express.json())

let todos = []
let id = 0

app.get('/', (req, res) => { res.sendFile('index.html', { root: __dirname }) })

app.get('/todos', (req, res) => {
  console.log("todos displayed")
  // sends all the todos
  res.status(200).send(todos)
})

app.post('/todos', (req, res) => {
  let { title, due } = req.body
  // creates a new todo using id (global variable)
  // and items taken from a post request
  let newTodo = { id: "" + id || -1, title: title || "", due: due || "" }
  // adds new Todo to the global list
  todos.push(newTodo)
  id++
  console.log(`todo ${id} pushed!`)
  res.status(201).send(newTodo)
})

app.get('/todos/:id', (req, res) => {
  const searchId = req.params.id
  // finds todo with id matching query string
  let results = todos.filter(x => x.id == searchId)
  console.log(`todo ${searchId} displayed`)
  res.status(200).send(results[0])
})

app.put('/todos/:id', (req, res) => {
  const searchId = req.params.id
  let results = todos.filter(x => x.id === searchId)
  let { title, due } = req.body
  let putTodo = { 
    id: req.params.id, 
    title: title || "", 
    due: due || "" }
  let newTodos = todos.filter(x => x.id !== searchId)
  newTodos.push(putTodo)
  todos = newTodos
  console.log(`todo ${searchId} replaced`)
  res.status(200).send(putTodo)
})

app.patch('/todos/:id', (req, res) => {
  const searchId = req.params.id
  let results = todos.filter(x => x.id === searchId)
  let { title, due } = req.body
  let patchTodo = { 
   id: req.params.id,
   title: title || results[0].title, 
   due: due || results[0].due }
  let newTodos = todos.filter(x => x.id !== searchId)
  newTodos.push(patchTodo)
  todos = newTodos
  console.log(`todo ${searchId} changed`)
  res.status(200).send(patchTodo)
})

app.delete('/todos/:id', (req, res) => {
  let searchId = req.params.id
  let newTodos = todos.filter(x => x.id !== searchId)
  todos = newTodos
  console.log(`todo ${searchId} deleted`)
  res.status(200).send({ "ok": `todo ${searchId} deleted` })
})

app.listen(3000, () => console.log("http://localhost:3000"))